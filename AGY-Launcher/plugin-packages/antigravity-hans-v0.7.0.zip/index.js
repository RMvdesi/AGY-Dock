const crypto = require('crypto');
const fs = require('fs');
const http = require('http');
const path = require('path');

const VERSION = require('./package.json').version;
const { CdpHansController, getJson } = require('./lib/cdp');
const { buildFontOverlaySource, loadFontSettings } = require('./lib/font-config');
const { readState, removeState, stopService, writeState } = require('./lib/service');

const DEFAULT_SERVER_PORT = 12397;
const serverPort = Number(process.env.ANTIGRAVITY_HANS_PORT || DEFAULT_SERVER_PORT);
const OVERLAY_SENTINEL = '__antigravityZhPatchInstalled';

function loadOverlayFile(filename) {
  const fullPath = path.join(__dirname, 'overlays', filename);
  const content = fs.readFileSync(fullPath, 'utf8');
  if (!content.includes(OVERLAY_SENTINEL)) {
    throw new Error(`Overlay script ${filename} is missing sentinel ${OVERLAY_SENTINEL}`);
  }
  return content;
}

function createControlServer({ port, shutdown, status }) {
  const token = crypto.randomBytes(24).toString('hex');
  const expectedAuth = `Bearer ${token}`;

  const server = http.createServer((req, res) => {
    try {
      const reqUrl = new URL(req.url, `http://127.0.0.1:${port}`);
      const pathname = decodeURIComponent(reqUrl.pathname);

      if (pathname === '/health' && req.method === 'GET') {
        const snapshot = status();
        res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
        res.end(
          JSON.stringify({
            ok: true,
            service: 'antigravity-hans',
            version: VERSION,
            runtime: 'node-cdp',
            port,
            cdpPort: snapshot.cdpPort,
            attachedPages: snapshot.attachedPages,
          })
        );
        return;
      }

      if (pathname === '/api/status' && req.method === 'GET') {
        const snapshot = status();
        res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
        res.end(JSON.stringify({ ok: true, service: 'antigravity-hans', version: VERSION, ...snapshot }));
        return;
      }

      if (pathname === '/api/shutdown' && req.method === 'POST') {
        const authHeader = String(req.headers.authorization || '');
        const valid =
          authHeader.length === expectedAuth.length &&
          crypto.timingSafeEqual(Buffer.from(authHeader), Buffer.from(expectedAuth));
        if (!valid) {
          res.writeHead(401, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
          res.end(JSON.stringify({ ok: false, error: 'Unauthorized' }));
          return;
        }
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: true, stopping: true }));
        setImmediate(shutdown);
        return;
      }

      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Not found');
    } catch {
      if (!res.headersSent) {
        res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Internal server error');
      } else {
        res.destroy();
      }
    }
  });

  return { server, token };
}

async function main() {
  if (process.argv.includes('--stop')) {
    const stopped = await stopService(serverPort);
    console.log(stopped ? '[antigravity-hans] Service stop signal sent.' : '[antigravity-hans] No running service found.');
    return;
  }

  if (process.argv.includes('--status')) {
    const state = readState();
    const health = await getJson(state?.port || serverPort, '/health').catch(() => null);
    if (!health) {
      console.log('[antigravity-hans] Service is not running.');
      process.exitCode = 1;
      return;
    }
    console.log(JSON.stringify(health, null, 2));
    return;
  }

  const overlaySource = loadOverlayFile('antigravity-hans-overlay.js');
  const swarmOverlaySource = loadOverlayFile('swarm-overlay.js');
  const settingsPath = process.env.ANTIGRAVITY_HANS_SETTINGS_FILE || path.join(__dirname, 'settings.json');
  const fontSettings = loadFontSettings(settingsPath);
  const fontOverlaySource = buildFontOverlaySource(fontSettings);

  const requestedPort = process.env.ANTIGRAVITY_HANS_CDP_PORT
    ? Number(process.env.ANTIGRAVITY_HANS_CDP_PORT)
    : null;
  if (requestedPort !== null && (!Number.isInteger(requestedPort) || requestedPort < 1 || requestedPort > 65535)) {
    throw new Error('Invalid ANTIGRAVITY_HANS_CDP_PORT');
  }

  if (process.argv.includes('--once')) {
    const onceController = new CdpHansController({
      overlaySource,
      swarmOverlaySource,
      fontOverlaySource,
      requestedPort,
    });
    const result = await onceController.injectOnce();
    if (!result.port) {
      console.log('[antigravity-hans] No active Antigravity CDP port found; nothing injected.');
    } else {
      console.log(`[antigravity-hans] Once mode injected ${result.injectedCount} target(s) on CDP port ${result.port}.`);
    }
    return;
  }

  let controller = null;
  let pollTimer = null;
  let closed = false;

  const close = () => {
    if (closed) return;
    closed = true;
    clearInterval(pollTimer);
    controller?.dispose();
    removeState(token);
    server.close(() => process.exit(0));
    server.closeAllConnections?.();
    const forceExit = setTimeout(() => process.exit(0), 2000);
    forceExit.unref();
  };

  const { server, token } = createControlServer({
    port: serverPort,
    shutdown: close,
    status: () => ({
      cdpPort: controller?.port || null,
      attachedPages: controller?.injectedCount || 0,
      fontSettings,
    }),
  });

  try {
    await new Promise((resolve, reject) => {
      server.once('error', reject);
      server.listen(serverPort, '127.0.0.1', resolve);
    });
  } catch (error) {
    if (error.code === 'EADDRINUSE') {
      const existing = await getJson(serverPort, '/health').catch(() => null);
      if (existing?.service === 'antigravity-hans') {
        console.log('[antigravity-hans] Service already running.');
        return;
      }
    }
    throw error;
  }

  try {
    writeState(serverPort, token, VERSION);

    controller = new CdpHansController({
      overlaySource,
      swarmOverlaySource,
      fontOverlaySource,
      requestedPort,
      onHostGone: process.argv.includes('--daemon') || process.argv.includes('--attach-only') ? close : () => {},
    });
    pollTimer = setInterval(() => controller.poll(), 5000);
    controller.poll();
    process.once('SIGINT', close);
    process.once('SIGTERM', close);
    server.on('error', (error) => {
      console.error(error.message);
      close();
    });
    console.log(`[antigravity-hans] HTTP health server listening on http://127.0.0.1:${serverPort}`);
    console.log(
      fontSettings.chineseFontEnabled
        ? `[antigravity-hans] Chinese font stack active: Google Sans + ${fontSettings.chineseFontFamily}`
        : '[antigravity-hans] Chinese font override disabled (using host default).'
    );
    console.log('[antigravity-hans] Pure Node.js CDP localization watcher started. Use --status or --stop to manage.');
  } catch (error) {
    close();
    throw error;
  }
}

if (require.main === module) {
  main().catch((error) => {
    console.error('[antigravity-hans]', error.message);
    process.exitCode = 1;
  });
}

module.exports = { createControlServer, loadOverlayFile };
