const fs = require('node:fs');
const http = require('node:http');
const path = require('node:path');
const crypto = require('node:crypto');
const { CdpController, getJson } = require('./lib/cdp');
const { writeState, removeState, stopService } = require('./lib/service');
const VERSION = require('./package.json').version;
const TELEMETRY_CORE_SOURCE = fs.readFileSync(path.join(__dirname, 'lib', 'telemetry-core.js'), 'utf8');

const DEFAULT_SERVER_PORT = 12398;
const serverPort = Number(process.env.AGY_TELEMETRY_PORT || DEFAULT_SERVER_PORT);

function sendJson(res, status, payload) {
  if (res.headersSent) { res.destroy(); return; }
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
  });
  res.end(JSON.stringify(payload));
}

function sendError(res, status, message) {
  if (res.headersSent) { res.destroy(); return; }
  res.writeHead(status, {
    'Content-Type': 'text/plain; charset=utf-8',
    'Cache-Control': 'no-store',
  });
  res.end(message);
}

function createControlServer({
  port = serverPort,
  token = crypto.randomBytes(32).toString('hex'),
  status = () => ({}),
  shutdown = () => {},
} = {}) {
  const server = http.createServer((req, res) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'no-referrer');
    try {
      const reqUrl = new URL(req.url, 'http://127.0.0.1');
      const pathname = reqUrl.pathname;
      const localPort = server.address()?.port || port;
      const allowedHosts = new Set([`127.0.0.1:${localPort}`, `localhost:${localPort}`]);
      if (!allowedHosts.has(String(req.headers.host || ''))) {
        sendError(res, 403, 'Invalid host');
        return;
      }

      if (pathname === '/health' && req.method === 'GET') {
        sendJson(res, 200, {
          service: 'agy-telemetry',
          version: VERSION,
          ...status(),
        });
        return;
      }

      if (pathname === '/api/shutdown') {
        const authorized =
          req.headers.authorization === `Bearer ${token}` || reqUrl.searchParams.get('token') === token;
        if (!authorized) { sendError(res, 403, 'Authentication required'); return; }
        if (req.method !== 'POST') { sendError(res, 405, 'Use POST'); return; }
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end('{"ok":true}', () => shutdown());
        return;
      }

      sendError(res, 404, 'Not found');
    } catch (error) {
      sendError(res, 500, error.message || 'Internal error');
    }
  });
  return { server, token };
}

function buildInjectionScript(token) {
  return `
(() => {
  if (window.__agy_telemetry_dispose) {
    try { window.__agy_telemetry_dispose(); } catch {}
  }

  const SESSION_TOKEN = ${JSON.stringify(token)};
  window.__agy_telemetry_session = SESSION_TOKEN;

  const STYLE_ID = 'agy-telemetry-style';
  const POPOVER_ID = 'agy-telemetry-popover';
  const BAR_ATTR = 'data-agy-telemetry-bar';

  const abort = new AbortController();
  const subscriptions = new Map(); // cascadeId -> { provider, unsub }
  const liveStepTtft = new Map();  // key -> ttftMs
  const liveStepTrack = new Map(); // key -> { decodeStartMs }
  const seenWaitingSteps = new Set(); // key seen before first content appeared
  const pendingTimers = new Set();
  let syncQueued = false;
  let pollTimer = null;
  let domObserver = null;

  let activeState = null; // { kind: 'speed'|'cache'|'context', anchorEl, cascadeId, pinned: boolean }
  let closeTimer = null;
  let hoveredExpandKey = null; // 'chat' | 'custom' | 'models' | null
  let suppressedHoverKey = null;
  const pinnedExpandKeys = new Set();
  let expandCloseTimer = null;

  const MODEL_HISTORY_STORAGE_KEY = 'agy_telemetry_model_history_v1';
  const learnedModelNames = new Map();
  const sessionModelHistory = new Map();
  let cachedClientModelConfigs = [];
  let lastPersistedModelSnapshot = '';

  function loadModelHistory() {
    try {
      if (typeof localStorage === 'undefined') return;
      const raw = localStorage.getItem(MODEL_HISTORY_STORAGE_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') {
        if (parsed.learned && typeof parsed.learned === 'object') {
          for (const [k, v] of Object.entries(parsed.learned)) {
            if (typeof k === 'string' && typeof v === 'string' && v.trim()) {
              learnedModelNames.set(k, v.trim());
            }
          }
        }
        if (parsed.sessions && typeof parsed.sessions === 'object') {
          for (const [cid, arr] of Object.entries(parsed.sessions)) {
            if (typeof cid === 'string' && Array.isArray(arr) && arr.length > 0) {
              sessionModelHistory.set(cid, arr);
            }
          }
        }
        lastPersistedModelSnapshot = raw;
      }
    } catch {}
  }

  function persistModelHistory() {
    try {
      if (typeof localStorage === 'undefined') return;
      while (learnedModelNames.size > 100) {
        learnedModelNames.delete(learnedModelNames.keys().next().value);
      }
      while (sessionModelHistory.size > 80) {
        sessionModelHistory.delete(sessionModelHistory.keys().next().value);
      }
      const payload = JSON.stringify({
        learned: Object.fromEntries(learnedModelNames.entries()),
        sessions: Object.fromEntries(sessionModelHistory.entries()),
      });
      if (payload !== lastPersistedModelSnapshot) {
        localStorage.setItem(MODEL_HISTORY_STORAGE_KEY, payload);
        lastPersistedModelSnapshot = payload;
      }
    } catch {}
  }

  loadModelHistory();

  const later = (fn, ms) => {
    const id = setTimeout(() => { pendingTimers.delete(id); fn(); }, ms);
    pendingTimers.add(id);
    return id;
  };

  function ensureStyle() {
    let styleEl = document.getElementById(STYLE_ID);
    if (styleEl) return styleEl;
    styleEl = document.createElement('style');
    styleEl.id = STYLE_ID;
    styleEl.textContent = \`
      .agy-telemetry-bar {
        display: inline-flex;
        align-items: center;
        gap: 2px;
        margin-right: 4px;
        height: 28px;
        flex-shrink: 0;
        user-select: none;
        -webkit-user-select: none;
        app-region: no-drag;
        -webkit-app-region: no-drag;
        font-family: var(--font-sans, "Google Sans Flex", "Google Sans", system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif);
        font-size: 12px;
        font-variant-numeric: tabular-nums;
        color: var(--muted-foreground, #71717a);
      }
      .agy-tel-pill {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        height: 26px;
        padding: 0 7px;
        border: none;
        border-radius: 7px;
        background: transparent;
        color: var(--muted-foreground, #71717a);
        font-family: inherit;
        font-size: 12px;
        font-weight: 500;
        line-height: 1;
        font-variant-numeric: tabular-nums;
        white-space: nowrap;
        cursor: pointer;
        outline: none;
        transition: background-color 130ms ease, color 130ms ease;
        app-region: no-drag;
        -webkit-app-region: no-drag;
      }
      .agy-tel-pill:hover,
      .agy-tel-pill[data-active="true"] {
        background: var(--secondary, rgba(10, 10, 12, 0.06));
        color: var(--foreground, #0a0a0c);
      }
      .agy-tel-icon {
        width: 14px;
        height: 14px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        opacity: 0.88;
      }
      .agy-tel-val {
        letter-spacing: -0.01em;
      }
      #\${POPOVER_ID} {
        position: fixed;
        z-index: 99999;
        min-width: 248px;
        max-width: 316px;
        padding: 12px 14px;
        border-radius: 12px;
        background: var(--popover, var(--card, var(--background, #ffffff)));
        color: var(--foreground, #0a0a0c);
        border: 1px solid var(--border, rgba(10, 10, 12, 0.1));
        box-shadow: 0 12px 32px -6px rgba(0, 0, 0, 0.16), 0 2px 8px -2px rgba(0, 0, 0, 0.08);
        font-family: var(--font-sans, "Google Sans Flex", "Google Sans", system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif);
        font-size: 12.5px;
        line-height: 1.45;
        font-variant-numeric: tabular-nums;
        pointer-events: auto;
        opacity: 0;
        transform: translateY(-4px) scale(0.985);
        transition: opacity 120ms ease, transform 120ms ease;
      }
      #\${POPOVER_ID}[data-open="true"] {
        opacity: 1;
        transform: translateY(0) scale(1);
      }
      body.theme-dark #\${POPOVER_ID} {
        border-color: rgba(255, 255, 255, 0.1);
        box-shadow: 0 14px 36px -4px rgba(0, 0, 0, 0.55), 0 2px 10px -2px rgba(0, 0, 0, 0.35);
      }
      .agy-pop-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
      }
      .agy-pop-title {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-size: 13px;
        font-weight: 600;
        color: var(--foreground, #0a0a0c);
      }
      .agy-pop-title-muted {
        color: var(--muted-foreground, #71717a);
        font-weight: 500;
      }
      .agy-pop-head-val {
        font-size: 13px;
        font-weight: 600;
        color: var(--foreground, #0a0a0c);
        white-space: nowrap;
      }
      .agy-pop-head-val-muted {
        font-weight: 500;
        color: var(--foreground, #0a0a0c);
      }
      .agy-pop-divider {
        height: 1px;
        background: var(--border, rgba(10, 10, 12, 0.08));
        margin: 9px 0;
      }
      body.theme-dark .agy-pop-divider {
        background: rgba(255, 255, 255, 0.09);
      }
      .agy-pop-rows {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
      .agy-pop-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 18px;
      }
      .agy-pop-label {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        color: var(--muted-foreground, #71717a);
        white-space: nowrap;
      }
      .agy-pop-val {
        color: var(--secondary-foreground, var(--foreground, #3f3f46));
        font-weight: 500;
        text-align: right;
        white-space: nowrap;
      }
      .agy-pop-row-sub .agy-pop-label,
      .agy-pop-row-sub .agy-pop-val {
        font-size: 11.5px;
        opacity: 0.82;
      }
      .agy-pop-row-indent {
        padding-left: 15px;
      }
      .agy-pop-model {
        font-family: var(--font-mono, ui-monospace, SFMono-Regular, Menlo, Consolas, monospace);
        font-size: 11px;
        color: var(--secondary-foreground, var(--muted-foreground, #52525b));
        overflow: hidden;
        text-overflow: ellipsis;
        max-width: 190px;
        white-space: nowrap;
      }
      .agy-pop-trigger {
        cursor: pointer;
        user-select: none;
        -webkit-user-select: none;
        transition: color 130ms ease;
      }
      .agy-pop-expandable:hover > .agy-pop-trigger .agy-pop-label,
      .agy-pop-expandable[data-open="true"] > .agy-pop-trigger .agy-pop-label {
        color: var(--foreground, #0a0a0c);
      }
      body.theme-dark .agy-pop-expandable:hover > .agy-pop-trigger .agy-pop-label,
      body.theme-dark .agy-pop-expandable[data-open="true"] > .agy-pop-trigger .agy-pop-label {
        color: #f4f4f5;
      }
      .agy-pop-chevron {
        opacity: 0.45;
        flex-shrink: 0;
        transition: transform 170ms cubic-bezier(0.22, 1, 0.36, 1), opacity 140ms ease;
      }
      .agy-pop-expandable:hover .agy-pop-chevron,
      .agy-pop-expandable[data-open="true"] .agy-pop-chevron {
        opacity: 0.9;
      }
      .agy-pop-expandable[data-open="true"] .agy-pop-chevron {
        transform: rotate(90deg);
      }
      .agy-pop-model-summary {
        display: inline-flex;
        align-items: center;
        justify-content: flex-end;
        gap: 5px;
        min-width: 0;
      }
      .agy-pop-model-summary .agy-pop-model {
        max-width: 145px;
      }
      .agy-pop-badge {
        font-family: var(--font-sans, system-ui, sans-serif);
        font-size: 10px;
        font-weight: 600;
        line-height: 1;
        padding: 2px 5px;
        border-radius: 999px;
        background: var(--secondary, rgba(10, 10, 12, 0.07));
        color: var(--muted-foreground, #71717a);
        flex-shrink: 0;
        transition: background-color 130ms ease, color 130ms ease;
      }
      body.theme-dark .agy-pop-badge {
        background: rgba(255, 255, 255, 0.1);
        color: #a1a1aa;
      }
      .agy-pop-expandable:hover .agy-pop-badge,
      .agy-pop-expandable[data-open="true"] .agy-pop-badge {
        color: var(--foreground, #0a0a0c);
      }
      body.theme-dark .agy-pop-expandable:hover .agy-pop-badge,
      body.theme-dark .agy-pop-expandable[data-open="true"] .agy-pop-badge {
        color: #f4f4f5;
      }
      .agy-pop-drawer {
        display: grid;
        grid-template-rows: 0fr;
        opacity: 0;
        transition: grid-template-rows 170ms cubic-bezier(0.22, 1, 0.36, 1), opacity 140ms ease;
      }
      .agy-pop-expandable[data-open="true"] .agy-pop-drawer {
        grid-template-rows: 1fr;
        opacity: 1;
      }
      .agy-pop-drawer-inner {
        overflow: hidden;
        min-height: 0;
      }
      .agy-pop-drawer-card {
        margin: 5px 0 2px 3.5px;
        padding: 1px 0 1px 11px;
        border-left: 1px solid var(--border, rgba(10, 10, 12, 0.11));
        background: transparent;
        border-radius: 0;
        display: flex;
        flex-direction: column;
        gap: 4px;
      }
      body.theme-dark .agy-pop-drawer-card {
        border-left-color: rgba(255, 255, 255, 0.13);
      }
      .agy-pop-drawer-models {
        margin: 6px 0 1px 2px;
        padding: 1px 0 1px 9px;
      }
      .agy-pop-row-models {
        align-items: flex-start;
      }
      .agy-pop-model-list {
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        gap: 2px;
        min-width: 0;
      }
      .agy-pop-model-full {
        max-width: 195px;
        white-space: normal;
        word-break: break-all;
        text-align: right;
      }
      .agy-model-dot {
        width: 6px;
        height: 6px;
        border-radius: 999px;
        background: #94a3b8;
        flex-shrink: 0;
      }
      .agy-model-dot-active {
        background: #10b981;
      }
      .agy-ctx-bar {
        display: flex;
        align-items: center;
        gap: 2px;
        width: 100%;
        height: 6px;
        border-radius: 999px;
        background: var(--secondary, rgba(10, 10, 12, 0.07));
        overflow: hidden;
        margin: 9px 0 10px 0;
      }
      body.theme-dark .agy-ctx-bar {
        background: rgba(255, 255, 255, 0.09);
      }
      .agy-ctx-seg {
        height: 100%;
        border-radius: 999px;
        min-width: 3px;
        transition: width 220ms ease;
      }
      .agy-dot {
        width: 8px;
        height: 8px;
        border-radius: 2.5px;
        flex-shrink: 0;
      }
    \`;
    document.head.appendChild(styleEl);
    return styleEl;
  }

  const {
    ICONS,
    escapeHtml,
    fmtDuration,
    fmtCompactTokens,
    fmtCapacityTokens,
    computeMetricsCore,
    renderPopoverHtmlCore,
  } = (() => {
    const module = { exports: {} };
    const exports = module.exports;
${TELEMETRY_CORE_SOURCE}
    return module.exports;
  })();

  function makeRingSvg(pct) {
    const r = 6;
    const c = 2 * Math.PI * r;
    const valid = typeof pct === 'number' && Number.isFinite(pct);
    const clamped = valid ? Math.max(0, Math.min(100, pct)) : 0;
    const drawPct = clamped > 0 ? Math.max(clamped, 4) : 0;
    const offset = c * (1 - drawPct / 100);
    let color = 'currentColor';
    if (valid && clamped >= 90) color = '#ef4444';
    else if (valid && clamped >= 75) color = '#f59e0b';
    return \`<svg width="14" height="14" viewBox="0 0 16 16" fill="none">
      <circle cx="8" cy="8" r="\${r}" stroke="currentColor" stroke-width="2" opacity="0.22"/>
      <circle cx="8" cy="8" r="\${r}" stroke="\${color}" stroke-width="2" stroke-linecap="round"
        stroke-dasharray="\${c.toFixed(2)}" stroke-dashoffset="\${offset.toFixed(2)}"
        transform="rotate(-90 8 8)"/>
    </svg>\`;
  }

  function getFiberKey(el) {
    if (!el) return null;
    for (const k of Object.keys(el)) {
      if (k.startsWith('__reactFiber$')) return k;
    }
    return null;
  }

  function extractCascadeIdFromBtn(btn) {
    const fk = getFiberKey(btn);
    if (fk) {
      let curr = btn[fk];
      for (let i = 0; i < 30 && curr; i++) {
        const cid = curr.memoizedProps?.cascadeId;
        if (typeof cid === 'string' && cid.length > 0 && cid !== '_new') {
          return cid;
        }
        curr = curr.return;
      }
    }
    const m = location.pathname.match(/\\/c\\/([a-zA-Z0-9-]+)/);
    return m ? m[1] : null;
  }

  function findPaneRoot(toolbar) {
    let el = toolbar;
    for (let i = 0; i < 8 && el; i++) {
      if (el.hasAttribute && (el.hasAttribute('data-split-overlaid') || el.classList.contains('browser-hole-opaque'))) {
        return el;
      }
      el = el.parentElement;
    }
    return document;
  }

  function disposeSub(sub) {
    if (!sub) return;
    if (typeof sub === 'function') sub();
    else if (typeof sub.dispose === 'function') sub.dispose();
  }

  function captureClientModelConfigs(val) {
    const data = val?.userStatus?.cascadeModelConfigData;
    if (!data || typeof data !== 'object') return;
    const primary = Array.isArray(data.clientModelConfigs) ? data.clientModelConfigs : [];
    const battle = Array.isArray(data.battleModeModelConfigs) ? data.battleModeModelConfigs : [];
    const combined = battle.length > 0 ? primary.concat(battle) : primary;
    if (combined.length > 0) {
      cachedClientModelConfigs = combined;
    }
  }

  function extractProviderFromEl(el, cascadeId) {
    const fk = getFiberKey(el);
    if (!fk) return null;
    let curr = el[fk];
    let foundProvider = null;
    for (let i = 0; i < 16 && curr; i++) {
      const val = curr.memoizedProps?.value;
      captureClientModelConfigs(val);
      if (!foundProvider) {
        const asp = val?.cascadeContext?.state?.agentStateProvider;
        if (asp && typeof asp.getState === 'function') {
          const st = asp.getState();
          if (!cascadeId || st?.conversationId === cascadeId) {
            foundProvider = asp;
          }
        }
      }
      if (foundProvider && cachedClientModelConfigs.length > 0) break;
      curr = curr.return;
    }
    return foundProvider;
  }

  function findProviderInSubtree(root, cascadeId) {
    const fast = root.querySelectorAll('div.relative.self-stretch.flex-grow.min-h-0');
    for (const el of fast) {
      const asp = extractProviderFromEl(el, cascadeId);
      if (asp) return asp;
    }
    const candidates = root.querySelectorAll('div');
    let checked = 0;
    for (const el of candidates) {
      const asp = extractProviderFromEl(el, cascadeId);
      if (asp) return asp;
      checked++;
      if (root === document && checked > 250) break;
    }
    return null;
  }

  function getAgentStateProvider(toolbar, cascadeId) {
    const cached = subscriptions.get(cascadeId);
    const paneRoot = findPaneRoot(toolbar);
    let provider = findProviderInSubtree(paneRoot, cascadeId);
    if (!provider && paneRoot !== document) {
      provider = findProviderInSubtree(document, cascadeId);
    }

    // Only fall back to cached provider if fiber lookup transiently missed during remount.
    // Never short-circuit before fiber lookup because Antigravity's getState() returns a
    // render-time snapshot closure; returning a stale provider freezes all telemetry.
    if (!provider && cached?.provider) {
      try {
        const st = cached.provider.getState();
        if (st?.conversationId === cascadeId) return cached.provider;
      } catch {}
    }

    if (provider && typeof provider.onDidChange === 'function') {
      if (cached && cached.provider !== provider) {
        try { disposeSub(cached.unsub); } catch {}
        subscriptions.delete(cascadeId);
      }
      if (!subscriptions.has(cascadeId)) {
        const unsub = provider.onDidChange(() => {
          scheduleSync();
        });
        subscriptions.set(cascadeId, { provider, unsub });
      }
    }
    return provider;
  }

  function computeMetrics(state, cascadeId) {
    const metrics = computeMetricsCore(state, cascadeId, {
      liveStepTtft,
      liveStepTrack,
      seenWaitingSteps,
      clientModelConfigs: cachedClientModelConfigs,
      learnedModelNames,
      sessionModelHistory,
    });
    persistModelHistory();
    return metrics;
  }

  function renderPopoverHtml(kind, m) {
    return renderPopoverHtmlCore(kind, m, {
      expandedKey: hoveredExpandKey,
      pinnedKeys: pinnedExpandKeys,
    });
  }

  function syncExpandAttributes(pop) {
    if (!pop) return;
    pop.querySelectorAll('.agy-pop-expandable').forEach((el) => {
      const k = el.getAttribute('data-expand-key');
      const pinned = pinnedExpandKeys.has(k);
      const open = pinned || k === hoveredExpandKey;
      el.setAttribute('data-open', open ? 'true' : 'false');
      el.setAttribute('data-pinned', pinned ? 'true' : 'false');
    });
    if (activeState?.anchorEl?.isConnected && pop.style.display === 'block') {
      later(() => {
        if (activeState?.anchorEl?.isConnected && pop.style.display === 'block') {
          positionPopover(pop, activeState.anchorEl);
        }
      }, 180);
    }
  }

  function getOrCreatePopover() {
    let pop = document.getElementById(POPOVER_ID);
    if (pop) return pop;
    pop = document.createElement('div');
    pop.id = POPOVER_ID;
    pop.style.display = 'none';
    pop.addEventListener('mouseenter', () => {
      if (closeTimer) { clearTimeout(closeTimer); closeTimer = null; }
      if (expandCloseTimer) { clearTimeout(expandCloseTimer); expandCloseTimer = null; }
    });
    pop.addEventListener('mouseover', (e) => {
      const exp = e.target?.closest ? e.target.closest('.agy-pop-expandable') : null;
      if (exp) {
        if (expandCloseTimer) { clearTimeout(expandCloseTimer); expandCloseTimer = null; }
        const key = exp.getAttribute('data-expand-key');
        if (suppressedHoverKey && suppressedHoverKey !== key) {
          suppressedHoverKey = null;
        }
        if (key && key !== suppressedHoverKey && key !== hoveredExpandKey) {
          hoveredExpandKey = key;
          syncExpandAttributes(pop);
        }
      } else {
        suppressedHoverKey = null;
        if (hoveredExpandKey) {
          if (expandCloseTimer) clearTimeout(expandCloseTimer);
          expandCloseTimer = later(() => {
            expandCloseTimer = null;
            hoveredExpandKey = null;
            syncExpandAttributes(pop);
          }, 90);
        }
      }
    });
    pop.addEventListener('click', (e) => {
      if (e.button !== 0) return;
      const trigger = e.target?.closest ? e.target.closest('.agy-pop-trigger') : null;
      const exp = trigger?.closest ? trigger.closest('.agy-pop-expandable') : null;
      if (!exp) return;
      e.stopPropagation();
      const key = exp.getAttribute('data-expand-key');
      if (!key) return;
      if (expandCloseTimer) { clearTimeout(expandCloseTimer); expandCloseTimer = null; }
      if (pinnedExpandKeys.has(key)) {
        pinnedExpandKeys.delete(key);
        if (hoveredExpandKey === key) hoveredExpandKey = null;
        suppressedHoverKey = key;
      } else {
        pinnedExpandKeys.add(key);
        suppressedHoverKey = null;
        if (activeState) activeState.pinned = true;
      }
      syncExpandAttributes(pop);
    });
    pop.addEventListener('mouseleave', () => {
      suppressedHoverKey = null;
      if (expandCloseTimer) clearTimeout(expandCloseTimer);
      expandCloseTimer = later(() => {
        expandCloseTimer = null;
        hoveredExpandKey = null;
        syncExpandAttributes(pop);
      }, 120);
      if (activeState && !activeState.pinned) scheduleClose();
    });
    document.body.appendChild(pop);
    return pop;
  }

  function positionPopover(pop, anchorEl) {
    const rect = anchorEl.getBoundingClientRect();
    const popRect = pop.getBoundingClientRect();
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    let left = rect.right - popRect.width;
    if (left < 8) left = 8;
    if (left + popRect.width > vw - 8) left = Math.max(8, vw - popRect.width - 8);
    let top = rect.bottom + 6;
    if (top + popRect.height > vh - 8) {
      top = Math.max(8, rect.top - popRect.height - 6);
    }
    pop.style.left = \`\${Math.round(left)}px\`;
    pop.style.top = \`\${Math.round(top)}px\`;
  }

  function clearActiveMarkers() {
    document.querySelectorAll('.agy-tel-pill[data-active="true"]').forEach((p) => {
      p.removeAttribute('data-active');
    });
  }

  function hidePopover() {
    if (closeTimer) { clearTimeout(closeTimer); closeTimer = null; }
    if (expandCloseTimer) { clearTimeout(expandCloseTimer); expandCloseTimer = null; }
    hoveredExpandKey = null;
    suppressedHoverKey = null;
    pinnedExpandKeys.clear();
    activeState = null;
    clearActiveMarkers();
    const pop = document.getElementById(POPOVER_ID);
    if (pop) {
      pop.removeAttribute('data-open');
      pop.style.display = 'none';
      pop.__agyLastHtml = '';
    }
  }

  function scheduleClose() {
    if (closeTimer) clearTimeout(closeTimer);
    closeTimer = later(() => {
      if (activeState && !activeState.pinned) {
        hidePopover();
      }
    }, 150);
  }

  function showPopover(kind, anchorEl, cascadeId, metrics, pinned = false) {
    if (closeTimer) { clearTimeout(closeTimer); closeTimer = null; }
    if (!activeState || activeState.anchorEl !== anchorEl || activeState.kind !== kind) {
      if (expandCloseTimer) { clearTimeout(expandCloseTimer); expandCloseTimer = null; }
      hoveredExpandKey = null;
      suppressedHoverKey = null;
      pinnedExpandKeys.clear();
    }
    clearActiveMarkers();
    anchorEl.setAttribute('data-active', 'true');
    activeState = { kind, anchorEl, cascadeId, pinned };

    const pop = getOrCreatePopover();
    const html = renderPopoverHtml(kind, metrics);
    if (pop.__agyLastHtml !== html) {
      pop.innerHTML = html;
      pop.__agyLastHtml = html;
    }
    pop.style.display = 'block';
    positionPopover(pop, anchorEl);
    requestAnimationFrame(() => {
      if (activeState && activeState.anchorEl === anchorEl) {
        pop.setAttribute('data-open', 'true');
      }
    });
  }

  function ensureBarForToolbar(toolbar, actionGroup, cascadeId) {
    let bar = toolbar.querySelector(\`[\${BAR_ATTR}]\`);
    if (!bar) {
      bar = document.createElement('div');
      bar.className = 'agy-telemetry-bar';
      bar.setAttribute(BAR_ATTR, '1');

      const makePill = (kind, initialIcon, initialText) => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'agy-tel-pill';
        btn.setAttribute('data-kind', kind);
        btn.innerHTML = \`<span class="agy-tel-icon">\${initialIcon}</span><span class="agy-tel-val">\${initialText}</span>\`;

        btn.addEventListener('mouseenter', () => {
          if (activeState?.pinned) return;
          const m = btn.__agyMetrics;
          if (m) showPopover(kind, btn, btn.__agyCascadeId, m, false);
        });
        btn.addEventListener('mouseleave', () => {
          if (!activeState?.pinned) scheduleClose();
        });
        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          const m = btn.__agyMetrics;
          if (!m) return;
          if (activeState && activeState.anchorEl === btn && activeState.pinned) {
            hidePopover();
          } else {
            showPopover(kind, btn, btn.__agyCascadeId, m, true);
          }
        });
        return btn;
      };

      bar.appendChild(makePill('speed', ICONS.speed, '-- tok/s'));
      bar.appendChild(makePill('cache', ICONS.cache, '--%'));
      bar.appendChild(makePill('context', makeRingSvg(null), '--%'));
    }

    if (bar.parentElement !== toolbar || bar.nextElementSibling !== actionGroup) {
      toolbar.insertBefore(bar, actionGroup);
    }
    bar.setAttribute('data-cascade-id', cascadeId);
    return bar;
  }

  function updateBar(bar, cascadeId, m) {
    const speedBtn = bar.querySelector('[data-kind="speed"]');
    const cacheBtn = bar.querySelector('[data-kind="cache"]');
    const ctxBtn = bar.querySelector('[data-kind="context"]');

    if (speedBtn) {
      speedBtn.__agyMetrics = m;
      speedBtn.__agyCascadeId = cascadeId;
      const valEl = speedBtn.querySelector('.agy-tel-val');
      const nextText = m.latestTps !== null ? \`\${m.latestTps} tok/s\` : '-- tok/s';
      if (valEl && valEl.textContent !== nextText) valEl.textContent = nextText;
    }

    if (cacheBtn) {
      cacheBtn.__agyMetrics = m;
      cacheBtn.__agyCascadeId = cascadeId;
      const valEl = cacheBtn.querySelector('.agy-tel-val');
      const nextText = m.cacheHitPct !== null ? \`\${m.cacheHitPct}%\` : '--%';
      if (valEl && valEl.textContent !== nextText) valEl.textContent = nextText;
    }

    if (ctxBtn) {
      ctxBtn.__agyMetrics = m;
      ctxBtn.__agyCascadeId = cascadeId;
      const iconEl = ctxBtn.querySelector('.agy-tel-icon');
      const valEl = ctxBtn.querySelector('.agy-tel-val');
      const nextText = m.ctxPct !== null ? \`\${m.ctxPct}%\` : '--%';
      if (valEl && valEl.textContent !== nextText) valEl.textContent = nextText;
      const pctKey = String(m.ctxPct);
      if (iconEl && ctxBtn.getAttribute('data-ring-pct') !== pctKey) {
        ctxBtn.setAttribute('data-ring-pct', pctKey);
        iconEl.innerHTML = makeRingSvg(m.ctxPct);
      }
    }

    if (activeState && activeState.cascadeId === cascadeId && activeState.anchorEl?.isConnected) {
      const pop = document.getElementById(POPOVER_ID);
      if (pop && pop.style.display === 'block') {
        const nextHtml = renderPopoverHtml(activeState.kind, m);
        if (pop.__agyLastHtml !== nextHtml) {
          pop.innerHTML = nextHtml;
          pop.__agyLastHtml = nextHtml;
          positionPopover(pop, activeState.anchorEl);
        }
      }
    }
  }

  function sync() {
    syncQueued = false;
    ensureStyle();

    const moreBtns = Array.from(document.querySelectorAll('button[data-testid="titlebar-more-actions"]'));
    const activeToolbars = new Set();

    for (const moreBtn of moreBtns) {
      const actionGroup = moreBtn.parentElement;
      const toolbar = moreBtn.closest('[data-testid="pane-titlebar-toolbar"]') || actionGroup?.parentElement;
      if (!toolbar || !actionGroup) continue;

      const cascadeId = extractCascadeIdFromBtn(moreBtn);
      if (!cascadeId) continue;

      activeToolbars.add(toolbar);
      const bar = ensureBarForToolbar(toolbar, actionGroup, cascadeId);
      const provider = getAgentStateProvider(toolbar, cascadeId);
      if (!provider) continue;

      const state = provider.getState();
      const metrics = computeMetrics(state, cascadeId);
      updateBar(bar, cascadeId, metrics);
    }

    // Remove stale bars whose toolbar disappeared or lost conversation button
    document.querySelectorAll(\`[\${BAR_ATTR}]\`).forEach((bar) => {
      if (!activeToolbars.has(bar.parentElement)) {
        bar.remove();
      }
    });

    if (activeState && (!activeState.anchorEl || !activeState.anchorEl.isConnected)) {
      hidePopover();
    }
  }

  function scheduleSync() {
    if (syncQueued) return;
    syncQueued = true;
    requestAnimationFrame(sync);
  }

  document.addEventListener('click', (e) => {
    if (!activeState) return;
    const pop = document.getElementById(POPOVER_ID);
    const inBar = e.target?.closest && e.target.closest(\`[\${BAR_ATTR}]\`);
    const inPop = pop && e.target && pop.contains(e.target);
    if (!inBar && !inPop) {
      hidePopover();
    }
  }, { capture: true, signal: abort.signal });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && activeState) {
      hidePopover();
    }
  }, { signal: abort.signal });

  window.addEventListener('resize', () => {
    if (activeState?.anchorEl?.isConnected) {
      const pop = document.getElementById(POPOVER_ID);
      if (pop && pop.style.display === 'block') positionPopover(pop, activeState.anchorEl);
    }
  }, { signal: abort.signal });

  domObserver = new MutationObserver(() => {
    scheduleSync();
  });
  if (document.body) {
    domObserver.observe(document.body, { childList: true, subtree: true });
  }

  pollTimer = setInterval(sync, 1000);

  window.__agy_telemetry_dispose = () => {
    abort.abort();
    if (domObserver) domObserver.disconnect();
    if (pollTimer) clearInterval(pollTimer);
    for (const tid of pendingTimers) clearTimeout(tid);
    pendingTimers.clear();
    for (const sub of subscriptions.values()) {
      try { disposeSub(sub.unsub); } catch {}
    }
    subscriptions.clear();
    liveStepTtft.clear();
    liveStepTrack.clear();
    seenWaitingSteps.clear();
    learnedModelNames.clear();
    sessionModelHistory.clear();
    cachedClientModelConfigs = [];
    lastPersistedModelSnapshot = '';
    hoveredExpandKey = null;
    suppressedHoverKey = null;
    pinnedExpandKeys.clear();
    activeState = null;
    document.querySelectorAll(\`[\${BAR_ATTR}]\`).forEach((el) => el.remove());
    const pop = document.getElementById(POPOVER_ID);
    if (pop) pop.remove();
    const st = document.getElementById(STYLE_ID);
    if (st) st.remove();
  };

  sync();
})();
`;
}

async function main() {
  if (!Number.isInteger(serverPort) || serverPort < 1 || serverPort > 65535) {
    throw new Error('AGY_TELEMETRY_PORT must be an integer between 1 and 65535');
  }
  if (process.argv.includes('--stop')) {
    await stopService(serverPort);
    return;
  }
  if (process.argv.includes('--status')) {
    const status = await getJson(serverPort, '/health');
    if (status?.service !== 'agy-telemetry') throw new Error('Telemetry service is not running');
    console.log(JSON.stringify(status, null, 2));
    return;
  }
  if (typeof WebSocket !== 'function') {
    throw new Error('Node.js 22 or later with built-in WebSocket support is required');
  }

  const requestedPort = process.env.AGY_TELEMETRY_CDP_PORT ? Number(process.env.AGY_TELEMETRY_CDP_PORT) : null;
  if (requestedPort !== null && (!Number.isInteger(requestedPort) || requestedPort < 1 || requestedPort > 65535)) {
    throw new Error('Invalid AGY_TELEMETRY_CDP_PORT');
  }

  if (process.argv.includes('--once')) {
    const onceToken = crypto.randomBytes(16).toString('hex');
    const onceController = new CdpController({
      script: buildInjectionScript(onceToken),
      requestedPort,
    });
    const result = await onceController.injectOnce();
    if (!result.port) {
      console.log('[agy-telemetry] No active Antigravity CDP port found; nothing injected.');
    } else {
      console.log(`[agy-telemetry] Once mode attached ${result.attachedPages} page(s) on CDP port ${result.port}.`);
    }
    return;
  }

  let controller;
  let pollTimer;
  let stopping = false;
  const close = () => {
    if (stopping) return;
    stopping = true;
    clearInterval(pollTimer);
    controller?.stop();
    removeState(serverPort, token);
    server.close();
    server.closeAllConnections();
    const forceExit = setTimeout(() => process.exit(0), 150);
    forceExit.unref();
  };

  const { server, token } = createControlServer({
    port: serverPort,
    shutdown: close,
    status: () => ({
      cdpPort: controller?.port || null,
      attachedPages: controller?.attachedPages || 0,
    }),
  });

  try {
    await new Promise((resolve, reject) => {
      server.once('error', reject);
      server.listen(serverPort, '127.0.0.1', resolve);
    });
  } catch (error) {
    if (error.code === 'EADDRINUSE') {
      const existing = await getJson(serverPort, '/health');
      if (existing?.service === 'agy-telemetry') {
        console.log('[agy-telemetry] Service already running.');
        return;
      }
    }
    throw error;
  }

  try {
    writeState(serverPort, token);

    controller = new CdpController({
      script: buildInjectionScript(token),
      requestedPort,
      onHostGone: process.argv.includes('--daemon') ? close : () => {},
    });
    pollTimer = setInterval(() => controller.poll(), 5000);
    controller.poll();
    process.once('SIGINT', close);
    process.once('SIGTERM', close);
    server.on('error', (error) => {
      console.error(error.message);
      close();
    });
    console.log(`[agy-telemetry] HTTP health server listening on http://127.0.0.1:${serverPort}`);
    console.log('[agy-telemetry] Waiting for Antigravity CDP. Use --status or --stop to manage.');
  } catch (error) {
    close();
    throw error;
  }
}

if (require.main === module) {
  main().catch((error) => {
    console.error('[agy-telemetry]', error.message);
    process.exitCode = 1;
  });
}

module.exports = { createControlServer, buildInjectionScript };
