const http = require('node:http');
const crypto = require('node:crypto');
const { CdpController, getJson } = require('./lib/cdp');
const { writeState, removeState, stopService } = require('./lib/service');
const VERSION = require('./package.json').version;

const DEFAULT_SERVER_PORT = 12398;
const serverPort = Number(process.env.AGY_TELEMETRY_PORT || DEFAULT_SERVER_PORT);

function sendJson(res, status, payload) {
  if (res.headersSent) { res.destroy(); return; }
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
  });
  res.end(JSON.stringify(payload));
}

function sendError(res, status, message) {
  if (res.headersSent) { res.destroy(); return; }
  res.writeHead(status, {
    'Content-Type': 'text/plain; charset=utf-8',
    'Cache-Control': 'no-store',
  });
  res.end(message);
}

function createControlServer({
  port = serverPort,
  token = crypto.randomBytes(32).toString('hex'),
  status = () => ({}),
  shutdown = () => {},
} = {}) {
  const server = http.createServer((req, res) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'no-referrer');
    try {
      const reqUrl = new URL(req.url, 'http://127.0.0.1');
      const pathname = reqUrl.pathname;
      const localPort = server.address()?.port || port;
      const allowedHosts = new Set([`127.0.0.1:${localPort}`, `localhost:${localPort}`]);
      if (!allowedHosts.has(String(req.headers.host || ''))) {
        sendError(res, 403, 'Invalid host');
        return;
      }

      if (pathname === '/health' && req.method === 'GET') {
        sendJson(res, 200, {
          service: 'agy-telemetry',
          version: VERSION,
          ...status(),
        });
        return;
      }

      if (pathname === '/api/shutdown') {
        const authorized =
          req.headers.authorization === `Bearer ${token}` || reqUrl.searchParams.get('token') === token;
        if (!authorized) { sendError(res, 403, 'Authentication required'); return; }
        if (req.method !== 'POST') { sendError(res, 405, 'Use POST'); return; }
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end('{"ok":true}', () => shutdown());
        return;
      }

      sendError(res, 404, 'Not found');
    } catch (error) {
      sendError(res, 500, error.message || 'Internal error');
    }
  });
  return { server, token };
}

function buildInjectionScript(token) {
  return `
(() => {
  if (window.__agy_telemetry_dispose) {
    try { window.__agy_telemetry_dispose(); } catch {}
  }

  const SESSION_TOKEN = ${JSON.stringify(token)};
  window.__agy_telemetry_session = SESSION_TOKEN;

  const STYLE_ID = 'agy-telemetry-style';
  const POPOVER_ID = 'agy-telemetry-popover';
  const BAR_ATTR = 'data-agy-telemetry-bar';

  const abort = new AbortController();
  const subscriptions = new Map(); // cascadeId -> { provider, unsub }
  const liveStepTtft = new Map();  // key -> ttftMs
  const liveStepTrack = new Map(); // key -> { decodeStartMs }
  const seenWaitingSteps = new Set(); // key seen before first content appeared
  const pendingTimers = new Set();
  let syncQueued = false;
  let pollTimer = null;
  let domObserver = null;

  let activeState = null; // { kind: 'speed'|'cache'|'context', anchorEl, cascadeId, pinned: boolean }
  let closeTimer = null;

  const later = (fn, ms) => {
    const id = setTimeout(() => { pendingTimers.delete(id); fn(); }, ms);
    pendingTimers.add(id);
    return id;
  };

  function ensureStyle() {
    let styleEl = document.getElementById(STYLE_ID);
    if (styleEl) return styleEl;
    styleEl = document.createElement('style');
    styleEl.id = STYLE_ID;
    styleEl.textContent = \`
      .agy-telemetry-bar {
        display: inline-flex;
        align-items: center;
        gap: 2px;
        margin-right: 4px;
        height: 28px;
        flex-shrink: 0;
        user-select: none;
        -webkit-user-select: none;
        app-region: no-drag;
        -webkit-app-region: no-drag;
        font-family: var(--font-sans, "Google Sans Flex", "Google Sans", system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif);
        font-size: 12px;
        font-variant-numeric: tabular-nums;
        color: var(--muted-foreground, #71717a);
      }
      .agy-tel-pill {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        height: 26px;
        padding: 0 7px;
        border: none;
        border-radius: 7px;
        background: transparent;
        color: var(--muted-foreground, #71717a);
        font-family: inherit;
        font-size: 12px;
        font-weight: 500;
        line-height: 1;
        font-variant-numeric: tabular-nums;
        white-space: nowrap;
        cursor: pointer;
        outline: none;
        transition: background-color 130ms ease, color 130ms ease;
        app-region: no-drag;
        -webkit-app-region: no-drag;
      }
      .agy-tel-pill:hover,
      .agy-tel-pill[data-active="true"] {
        background: var(--secondary, rgba(10, 10, 12, 0.06));
        color: var(--foreground, #0a0a0c);
      }
      .agy-tel-icon {
        width: 14px;
        height: 14px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        opacity: 0.88;
      }
      .agy-tel-val {
        letter-spacing: -0.01em;
      }
      #\${POPOVER_ID} {
        position: fixed;
        z-index: 99999;
        min-width: 248px;
        max-width: 316px;
        padding: 12px 14px;
        border-radius: 12px;
        background: var(--popover, var(--card, var(--background, #ffffff)));
        color: var(--foreground, #0a0a0c);
        border: 1px solid var(--border, rgba(10, 10, 12, 0.1));
        box-shadow: 0 12px 32px -6px rgba(0, 0, 0, 0.16), 0 2px 8px -2px rgba(0, 0, 0, 0.08);
        font-family: var(--font-sans, "Google Sans Flex", "Google Sans", system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif);
        font-size: 12.5px;
        line-height: 1.45;
        font-variant-numeric: tabular-nums;
        pointer-events: auto;
        opacity: 0;
        transform: translateY(-4px) scale(0.985);
        transition: opacity 120ms ease, transform 120ms ease;
      }
      #\${POPOVER_ID}[data-open="true"] {
        opacity: 1;
        transform: translateY(0) scale(1);
      }
      body.theme-dark #\${POPOVER_ID} {
        border-color: rgba(255, 255, 255, 0.1);
        box-shadow: 0 14px 36px -4px rgba(0, 0, 0, 0.55), 0 2px 10px -2px rgba(0, 0, 0, 0.35);
      }
      .agy-pop-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
      }
      .agy-pop-title {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-size: 13px;
        font-weight: 600;
        color: var(--foreground, #0a0a0c);
      }
      .agy-pop-title-muted {
        color: var(--muted-foreground, #71717a);
        font-weight: 500;
      }
      .agy-pop-head-val {
        font-size: 13px;
        font-weight: 600;
        color: var(--foreground, #0a0a0c);
        white-space: nowrap;
      }
      .agy-pop-head-val-muted {
        font-weight: 500;
        color: var(--foreground, #0a0a0c);
      }
      .agy-pop-divider {
        height: 1px;
        background: var(--border, rgba(10, 10, 12, 0.08));
        margin: 9px 0;
      }
      body.theme-dark .agy-pop-divider {
        background: rgba(255, 255, 255, 0.09);
      }
      .agy-pop-rows {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
      .agy-pop-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 18px;
      }
      .agy-pop-label {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        color: var(--muted-foreground, #71717a);
        white-space: nowrap;
      }
      .agy-pop-val {
        color: var(--secondary-foreground, var(--foreground, #3f3f46));
        font-weight: 500;
        text-align: right;
        white-space: nowrap;
      }
      .agy-pop-row-sub .agy-pop-label,
      .agy-pop-row-sub .agy-pop-val {
        font-size: 11.5px;
        opacity: 0.82;
      }
      .agy-pop-model {
        font-family: var(--font-mono, ui-monospace, SFMono-Regular, Menlo, Consolas, monospace);
        font-size: 11px;
        color: var(--secondary-foreground, var(--muted-foreground, #52525b));
        overflow: hidden;
        text-overflow: ellipsis;
        max-width: 190px;
        white-space: nowrap;
      }
      .agy-ctx-bar {
        display: flex;
        align-items: center;
        gap: 2px;
        width: 100%;
        height: 6px;
        border-radius: 999px;
        background: var(--secondary, rgba(10, 10, 12, 0.07));
        overflow: hidden;
        margin: 9px 0 10px 0;
      }
      body.theme-dark .agy-ctx-bar {
        background: rgba(255, 255, 255, 0.09);
      }
      .agy-ctx-seg {
        height: 100%;
        border-radius: 999px;
        min-width: 3px;
        transition: width 220ms ease;
      }
      .agy-dot {
        width: 8px;
        height: 8px;
        border-radius: 2.5px;
        flex-shrink: 0;
      }
    \`;
    document.head.appendChild(styleEl);
    return styleEl;
  }

  const ICONS = {
    speed: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.85" stroke-linecap="round" stroke-linejoin="round"><path d="M12 14l4-4"/><path d="M3.34 19a10 10 0 1 1 17.32 0"/><path d="M6.5 17.5a6.5 6.5 0 0 1 11 0" opacity="0.35"/></svg>',
    cache: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.85" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="12" cy="5.5" rx="7.5" ry="2.8"/><path d="M4.5 5.5v6.5c0 1.55 3.36 2.8 7.5 2.8s7.5-1.25 7.5-2.8V5.5"/><path d="M4.5 12v6.5c0 1.55 3.36 2.8 7.5 2.8s7.5-1.25 7.5-2.8V12"/></svg>',
  };

  function makeRingSvg(pct) {
    const r = 6;
    const c = 2 * Math.PI * r;
    const valid = typeof pct === 'number' && Number.isFinite(pct);
    const clamped = valid ? Math.max(0, Math.min(100, pct)) : 0;
    const drawPct = clamped > 0 ? Math.max(clamped, 4) : 0;
    const offset = c * (1 - drawPct / 100);
    let color = 'currentColor';
    if (valid && clamped >= 90) color = '#ef4444';
    else if (valid && clamped >= 75) color = '#f59e0b';
    return \`<svg width="14" height="14" viewBox="0 0 16 16" fill="none">
      <circle cx="8" cy="8" r="\${r}" stroke="currentColor" stroke-width="2" opacity="0.22"/>
      <circle cx="8" cy="8" r="\${r}" stroke="\${color}" stroke-width="2" stroke-linecap="round"
        stroke-dasharray="\${c.toFixed(2)}" stroke-dashoffset="\${offset.toFixed(2)}"
        transform="rotate(-90 8 8)"/>
    </svg>\`;
  }

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function toMs(ts) {
    if (!ts) return null;
    const sec = Number(ts.seconds ?? 0);
    const nanos = Number(ts.nanos ?? 0);
    if (!Number.isFinite(sec) || sec <= 0) return null;
    return sec * 1000 + Math.round(nanos / 1e6);
  }

  function toDurMs(dur) {
    if (!dur) return 0;
    const sec = Number(dur.seconds ?? 0);
    const nanos = Number(dur.nanos ?? 0);
    if (!Number.isFinite(sec)) return 0;
    return Math.max(0, sec * 1000 + Math.round(nanos / 1e6));
  }

  function fmtDuration(ms) {
    if (ms === null || ms === undefined || !Number.isFinite(ms) || ms <= 0) return '--';
    const totalSec = ms / 1000;
    if (totalSec < 60) {
      if (totalSec >= 10) return \`\${totalSec.toFixed(1).replace(/\\.0$/, '')}秒\`;
      return \`\${totalSec.toFixed(1).replace(/\\.0$/, '')}秒\`;
    }
    const mins = Math.floor(totalSec / 60);
    const secs = Math.round(totalSec % 60);
    if (mins >= 60) {
      const hrs = Math.floor(mins / 60);
      const remMins = mins % 60;
      return \`\${hrs}小时\${remMins}分\`;
    }
    return secs > 0 ? \`\${mins}分\${secs}秒\` : \`\${mins}分\`;
  }

  function fmtCompactTokens(num) {
    const n = Number(num || 0);
    if (!Number.isFinite(n) || n <= 0) return '0';
    if (n >= 1_000_000) {
      const val = n / 1_000_000;
      const fixed = val >= 10 || Math.abs(val - Math.round(val)) < 0.05 ? Math.round(val).toString() : val.toFixed(1);
      return \`\${fixed.replace(/\\.0$/, '')}M\`;
    }
    if (n >= 1_000) {
      const val = n / 1_000;
      const fixed = val >= 100 ? Math.round(val).toString() : val.toFixed(1);
      return \`\${fixed.replace(/\\.0$/, '')}K\`;
    }
    return Math.round(n).toLocaleString();
  }

  function fmtCapacityTokens(num) {
    const n = Number(num || 0);
    if (!Number.isFinite(n) || n <= 0) return '1M';
    if (n >= 1_000_000) {
      const m = n / 1_000_000;
      return \`\${(m >= 10 || Math.abs(m - Math.round(m)) < 0.08 ? Math.round(m) : m.toFixed(1)).toString().replace(/\\.0$/, '')}M\`;
    }
    if (n >= 1_000) {
      return \`\${Math.round(n / 1_000)}K\`;
    }
    return String(Math.round(n));
  }

  function getFiberKey(el) {
    if (!el) return null;
    for (const k of Object.keys(el)) {
      if (k.startsWith('__reactFiber$')) return k;
    }
    return null;
  }

  function extractCascadeIdFromBtn(btn) {
    const fk = getFiberKey(btn);
    if (fk) {
      let curr = btn[fk];
      for (let i = 0; i < 30 && curr; i++) {
        const cid = curr.memoizedProps?.cascadeId;
        if (typeof cid === 'string' && cid.length > 0 && cid !== '_new') {
          return cid;
        }
        curr = curr.return;
      }
    }
    const m = location.pathname.match(/\\/c\\/([a-zA-Z0-9-]+)/);
    return m ? m[1] : null;
  }

  function findPaneRoot(toolbar) {
    let el = toolbar;
    for (let i = 0; i < 8 && el; i++) {
      if (el.hasAttribute && (el.hasAttribute('data-split-overlaid') || el.classList.contains('browser-hole-opaque'))) {
        return el;
      }
      el = el.parentElement;
    }
    return document;
  }

  function disposeSub(sub) {
    if (!sub) return;
    if (typeof sub === 'function') sub();
    else if (typeof sub.dispose === 'function') sub.dispose();
  }

  function extractProviderFromEl(el, cascadeId) {
    const fk = getFiberKey(el);
    if (!fk) return null;
    let curr = el[fk];
    for (let i = 0; i < 16 && curr; i++) {
      const val = curr.memoizedProps?.value;
      const asp = val?.cascadeContext?.state?.agentStateProvider;
      if (asp && typeof asp.getState === 'function') {
        const st = asp.getState();
        if (!cascadeId || st?.conversationId === cascadeId) {
          return asp;
        }
      }
      curr = curr.return;
    }
    return null;
  }

  function findProviderInSubtree(root, cascadeId) {
    const fast = root.querySelectorAll('div.relative.self-stretch.flex-grow.min-h-0');
    for (const el of fast) {
      const asp = extractProviderFromEl(el, cascadeId);
      if (asp) return asp;
    }
    const candidates = root.querySelectorAll('div');
    let checked = 0;
    for (const el of candidates) {
      const asp = extractProviderFromEl(el, cascadeId);
      if (asp) return asp;
      checked++;
      if (root === document && checked > 250) break;
    }
    return null;
  }

  function getAgentStateProvider(toolbar, cascadeId) {
    const cached = subscriptions.get(cascadeId);
    const paneRoot = findPaneRoot(toolbar);
    let provider = findProviderInSubtree(paneRoot, cascadeId);
    if (!provider && paneRoot !== document) {
      provider = findProviderInSubtree(document, cascadeId);
    }

    // Only fall back to cached provider if fiber lookup transiently missed during remount.
    // Never short-circuit before fiber lookup because Antigravity's getState() returns a
    // render-time snapshot closure; returning a stale provider freezes all telemetry.
    if (!provider && cached?.provider) {
      try {
        const st = cached.provider.getState();
        if (st?.conversationId === cascadeId) return cached.provider;
      } catch {}
    }

    if (provider && typeof provider.onDidChange === 'function') {
      if (cached && cached.provider !== provider) {
        try { disposeSub(cached.unsub); } catch {}
        subscriptions.delete(cascadeId);
      }
      if (!subscriptions.has(cascadeId)) {
        const unsub = provider.onDidChange(() => {
          scheduleSync();
        });
        subscriptions.set(cascadeId, { provider, unsub });
      }
    }
    return provider;
  }

  function medianOf(sortedNums) {
    if (!sortedNums.length) return 0;
    const mid = Math.floor(sortedNums.length / 2);
    return sortedNums.length % 2 === 1
      ? sortedNums[mid]
      : (sortedNums[mid - 1] + sortedNums[mid]) / 2;
  }

  // Estimate fixed per-request overhead T_0 (server queue + proxy RTT + prefill)
  // using Theil-Sen median slope on T(n) = T_0 + n / v over recent steps.
  function estimateSessionOverheadMs(rawPlanner) {
    const recent = rawPlanner.slice(-80);
    const slopes = [];
    for (let i = 0; i < recent.length; i++) {
      for (let j = i + 1; j < recent.length; j++) {
        const dx = recent[j].outTok - recent[i].outTok;
        const dy = recent[j].stepGenMs - recent[i].stepGenMs;
        if (Math.abs(dx) >= 300) {
          const slope = dy / dx;
          if (slope >= 0.8 && slope <= 40) {
            slopes.push(slope);
          }
        }
      }
    }
    if (slopes.length < 3) return 0;
    slopes.sort((a, b) => a - b);
    const medSlope = medianOf(slopes);
    const t0s = recent
      .map((r) => r.stepGenMs - medSlope * r.outTok)
      .filter((v) => Number.isFinite(v))
      .sort((a, b) => a - b);
    const rawT0 = medianOf(t0s);
    return Math.max(0, Math.min(12_000, rawT0));
  }

  function computeMetrics(state, cascadeId) {
    const ts = state?.trajectorySlice || {};
    const steps = Array.isArray(ts.stepsInSlice) ? ts.stepsInSlice : [];

    const userInputs = steps.filter((s) => s.step?.case === 'userInput').length;
    const turns = Array.isArray(state?.turns) && state.turns.length > 0 ? state.turns.length : userInputs;
    const stepCount = Number(ts.totalStepsLength || steps.length || 0);

    let totalModelMs = 0;
    let totalToolMs = 0;
    let totalUncachedInput = 0;
    let totalCacheRead = 0;
    let totalOutput = 0;
    let totalThinkingOut = 0;
    let totalResponseOut = 0;

    let ttftSumMs = 0;
    let ttftCount = 0;
    const rawPlanner = [];
    const now = Date.now();

    steps.forEach((s, idx) => {
      const stepCase = s.step?.case;
      const m = s.metadata || {};

      if (stepCase === 'plannerResponse') {
        const u = m.modelUsage || {};
        const inTok = Number(u.inputTokens ?? 0);
        const cacheReadTok = Number(u.cacheReadTokens ?? 0);
        const outTok = Number(u.outputTokens ?? 0);
        const thinkTok = Number(u.thinkingOutputTokens ?? 0);
        const respTok = Number(u.responseOutputTokens ?? 0);

        totalUncachedInput += inTok;
        totalCacheRead += cacheReadTok;
        totalOutput += outTok;
        totalThinkingOut += thinkTok;
        totalResponseOut += respTok;

        const cMs = toMs(m.createdAt);
        const vMs = toMs(m.viewableAt);
        const fMs = toMs(m.finishedGeneratingAt);
        const thinkMs = toDurMs(s.step?.value?.thinkingDuration);

        // Live TTFT & decodeStartMs observation during active streaming
        const stepKey = \`\${cascadeId}:\${m.modelApiContentId || m.sourceTrajectoryStepInfo?.stepIndex || idx}\`;
        const hasFirstContent = Boolean(
          s.step?.value?.response ||
          s.step?.value?.thinking ||
          s.step?.value?.rawThinking ||
          (s.step?.value?.toolCalls && s.step.value.toolCalls.length > 0)
        );
        if (cMs && !fMs) {
          if (!hasFirstContent) {
            if (seenWaitingSteps.size > 500) {
              seenWaitingSteps.delete(seenWaitingSteps.values().next().value);
            }
            seenWaitingSteps.add(stepKey);
          } else {
            if (!liveStepTtft.has(stepKey)) {
              const observed = now - cMs;
              if (observed > 0 && observed < 120_000) {
                if (liveStepTtft.size > 500) {
                  liveStepTtft.delete(liveStepTtft.keys().next().value);
                }
                liveStepTtft.set(stepKey, observed);
              }
            }
            // Only anchor decodeStartMs when we observed the pre-content transition
            // so mid-stream attachment does not clip earlier token generation time.
            if (seenWaitingSteps.has(stepKey) && !liveStepTrack.has(stepKey)) {
              if (liveStepTrack.size > 500) {
                liveStepTrack.delete(liveStepTrack.keys().next().value);
              }
              liveStepTrack.set(stepKey, { decodeStartMs: now });
            }
          }
        }

        let stepTtft = null;
        if (liveStepTtft.has(stepKey)) {
          stepTtft = liveStepTtft.get(stepKey);
        } else if (cMs && vMs && vMs >= cMs) {
          stepTtft = vMs - cMs;
        }
        if (stepTtft !== null && stepTtft > 0) {
          ttftSumMs += stepTtft;
          ttftCount++;
        }

        let stepGenMs = 0;
        if (cMs && fMs && fMs > cMs) {
          stepGenMs = fMs - cMs;
        } else if (thinkMs > 0) {
          stepGenMs = thinkMs;
        } else if (cMs && s.status !== 3) {
          stepGenMs = Math.max(0, now - cMs);
        }
        totalModelMs += stepGenMs;

        if (outTok > 0 && stepGenMs > 0) {
          const track = liveStepTrack.get(stepKey);
          let directDecodeMs = null;
          if (track?.decodeStartMs && cMs) {
            const endMs = fMs || now;
            const dMs = endMs - track.decodeStartMs;
            if (
              dMs >= 1500 &&
              (track.decodeStartMs - cMs) < stepGenMs * 0.85 &&
              (outTok / (dMs / 1000)) <= 800
            ) {
              directDecodeMs = dMs;
            }
          }
          rawPlanner.push({ outTok, stepGenMs, directDecodeMs });
        }
      } else if (stepCase && stepCase !== 'userInput') {
        const sMs = toMs(m.startedAt);
        const eMs = toMs(m.completedAt);
        if (sMs && eMs && eMs >= sMs) {
          totalToolMs += (eMs - sMs);
        }
      }
    });

    const avgTtftMs = ttftCount > 0 ? Math.round(ttftSumMs / ttftCount) : null;

    // Subtract either direct live decode start or session fixed overhead T_0
    // when residual decode duration remains >= 1500 ms (avoids sub-second spikes).
    const regressionPool = rawPlanner.filter((r) => (r.outTok / (r.stepGenMs / 1000)) <= 800);
    const estT0 = estimateSessionOverheadMs(regressionPool);
    const speedCandidates = rawPlanner.map((r) => {
      let effMs = r.stepGenMs;
      if (r.directDecodeMs !== null) {
        effMs = r.directDecodeMs;
      } else if (estT0 > 0 && (r.stepGenMs - estT0) >= 1500 && estT0 <= r.stepGenMs * 0.78) {
        effMs = r.stepGenMs - estT0;
      }
      const rawTps = effMs > 0 ? (r.outTok / (effMs / 1000)) : 0;
      const valid = effMs >= 1200 && rawTps > 0 && rawTps <= 800;
      return {
        outTok: r.outTok,
        effMs,
        tps: valid ? rawTps : 0,
        invalid: !valid,
      };
    });

    // Two-tier decode sampling + median stall rejection + rolling recent rate:
    // 1. Prefer sustained steps (>= 350 output tok and >= 1500 ms decode) for true decode rate.
    // 2. Fallback to medium steps (>= 180 output tok and >= 1000 ms) only before sustained steps exist.
    // 3. Reject severe stalls (< 60% of sample median) when >= 3 valid samples exist.
    const validCandidates = speedCandidates.filter((x) => !x.invalid);
    const primarySamples = validCandidates.filter((x) => x.outTok >= 350 && x.effMs >= 1500);
    let samplePool = primarySamples;
    let speedTier = 'sustained';
    if (samplePool.length === 0) {
      samplePool = validCandidates.filter((x) => x.outTok >= 180 && x.effMs >= 1000);
      speedTier = samplePool.length > 0 ? 'fallback' : 'none';
    }

    let filteredSamples = samplePool;
    if (samplePool.length >= 3) {
      const sortedTps = samplePool.map((x) => x.tps).sort((a, b) => a - b);
      const medianTps = medianOf(sortedTps);
      const nonStall = samplePool.filter((x) => x.tps >= medianTps * 0.60);
      if (nonStall.length > 0) {
        filteredSamples = nonStall;
      }
    }

    const recentWindow = filteredSamples.slice(-4);
    const sumRecentOut = recentWindow.reduce((acc, x) => acc + x.outTok, 0);
    const sumRecentMs = recentWindow.reduce((acc, x) => acc + x.effMs, 0);
    const latestTps = sumRecentMs > 0 ? Math.round(sumRecentOut / (sumRecentMs / 1000)) : null;

    const sumSampleOut = filteredSamples.reduce((acc, x) => acc + x.outTok, 0);
    const sumSampleMs = filteredSamples.reduce((acc, x) => acc + x.effMs, 0);
    const avgTps = sumSampleMs > 0 ? Math.round(sumSampleOut / (sumSampleMs / 1000)) : null;
    const speedSampleCount = filteredSamples.length;
    const speedTotalCandidates = speedCandidates.length;

    const totalTokens = totalUncachedInput + totalCacheRead + totalOutput;
    const cacheDenom = totalUncachedInput + totalCacheRead;
    const cacheHitPct = cacheDenom > 0 ? Math.round((totalCacheRead / cacheDenom) * 100) : null;

    const cwu = state?.contextWindowUsage || null;
    const ctxUsed = Number(cwu?.estimatedTokensUsed ?? 0);
    const ctxMax = Number(cwu?.maxContextTokens ?? 0);
    const ctxPct = ctxMax > 0 ? Math.min(100, Math.round((ctxUsed / ctxMax) * 100)) : null;

    let sysTokens = 0;
    let toolsTokens = 0;
    let chatTokens = 0;
    for (const g of (cwu?.tokenGroups || [])) {
      const n = Number(g?.numTokens ?? 0);
      const name = String(g?.name || '').toLowerCase();
      if (g?.type === 1 || name.includes('system')) sysTokens += n;
      else if (g?.type === 2 || name.includes('tool')) toolsTokens += n;
      else if (g?.type === 7 || name.includes('chat') || name.includes('message')) chatTokens += n;
      else chatTokens += n;
    }

    let modelName = '';
    const genMetas = Array.isArray(ts.generatorMetadatasInSlice) ? ts.generatorMetadatasInSlice : [];
    for (let i = genMetas.length - 1; i >= 0; i--) {
      const mn = genMetas[i]?.plannerConfig?.modelName;
      if (typeof mn === 'string' && mn.trim()) {
        modelName = mn.trim();
        break;
      }
    }

    return {
      turns,
      stepCount,
      latestTps,
      avgTps,
      speedSampleCount,
      speedTotalCandidates,
      speedTier,
      totalModelMs,
      totalToolMs,
      avgTtftMs,
      totalTokens,
      cacheHitPct,
      totalUncachedInput,
      totalCacheRead,
      totalOutput,
      totalThinkingOut,
      totalResponseOut,
      ctxUsed,
      ctxMax,
      ctxPct,
      sysTokens,
      toolsTokens,
      chatTokens,
      modelName,
    };
  }

  function renderPopoverHtml(kind, m) {
    if (kind === 'speed') {
      const tpsDisplay = m.latestTps !== null
        ? (m.avgTps !== null && m.avgTps !== m.latestTps ? \`\${m.latestTps} / \${m.avgTps} tok/s\` : \`\${m.latestTps} tok/s\`)
        : '--';
      const tpsLabel = (m.avgTps !== null && m.latestTps !== null && m.avgTps !== m.latestTps)
        ? '输出速度 (近期 / 全局)'
        : '输出速度 (TPS)';
      let sampleNote = '';
      if (m.speedTotalCandidates > 0) {
        const ignored = m.speedTotalCandidates - m.speedSampleCount;
        if (m.speedSampleCount > 0) {
          sampleNote = ignored > 0
            ? \`\${m.speedSampleCount} 步 (已过滤 \${ignored} 短步)\`
            : \`\${m.speedSampleCount} 步\`;
        } else {
          sampleNote = \`0 / \${m.speedTotalCandidates} 步 (过短已忽略)\`;
        }
      }
      return \`
        <div class="agy-pop-head">
          <span class="agy-pop-title">\${ICONS.speed}<span>会话统计</span></span>
          <span class="agy-pop-head-val">\${m.turns} 轮 \${m.stepCount} 步</span>
        </div>
        <div class="agy-pop-divider"></div>
        <div class="agy-pop-rows">
          <div class="agy-pop-row">
            <span class="agy-pop-label">模型用时</span>
            <span class="agy-pop-val">\${fmtDuration(m.totalModelMs)}</span>
          </div>
          <div class="agy-pop-row">
            <span class="agy-pop-label">工具调用用时</span>
            <span class="agy-pop-val">\${fmtDuration(m.totalToolMs)}</span>
          </div>
          <div class="agy-pop-row">
            <span class="agy-pop-label">首 token 平均 (TTFT)</span>
            <span class="agy-pop-val">\${fmtDuration(m.avgTtftMs)}</span>
          </div>
          <div class="agy-pop-row">
            <span class="agy-pop-label">\${tpsLabel}</span>
            <span class="agy-pop-val">\${tpsDisplay}</span>
          </div>
          \${sampleNote ? \`
          <div class="agy-pop-row agy-pop-row-sub">
            <span class="agy-pop-label">有效采样</span>
            <span class="agy-pop-val">\${sampleNote}</span>
          </div>\` : ''}
        </div>
      \`;
    }

    if (kind === 'cache') {
      const hasSplit = m.totalThinkingOut > 0 || m.totalResponseOut > 0;
      return \`
        <div class="agy-pop-head">
          <span class="agy-pop-title">\${ICONS.cache}<span>Token 用量</span></span>
          <span class="agy-pop-head-val">\${m.totalTokens.toLocaleString()} tok</span>
        </div>
        <div class="agy-pop-divider"></div>
        <div class="agy-pop-rows">
          <div class="agy-pop-row">
            <span class="agy-pop-label">缓存命中</span>
            <span class="agy-pop-val">\${m.cacheHitPct !== null ? \`\${m.cacheHitPct}%\` : '--'}</span>
          </div>
          <div class="agy-pop-row">
            <span class="agy-pop-label">未缓存输入</span>
            <span class="agy-pop-val">\${m.totalUncachedInput.toLocaleString()} tok</span>
          </div>
          <div class="agy-pop-row">
            <span class="agy-pop-label">缓存读取</span>
            <span class="agy-pop-val">\${m.totalCacheRead.toLocaleString()} tok</span>
          </div>
          <div class="agy-pop-row">
            <span class="agy-pop-label">输出</span>
            <span class="agy-pop-val">\${m.totalOutput.toLocaleString()} tok</span>
          </div>
          \${hasSplit ? \`
          <div class="agy-pop-row agy-pop-row-sub">
            <span class="agy-pop-label">思考 / 回复</span>
            <span class="agy-pop-val">\${m.totalThinkingOut.toLocaleString()} / \${m.totalResponseOut.toLocaleString()} tok</span>
          </div>\` : ''}
        </div>
      \`;
    }

    // context
    const maxCap = m.ctxMax > 0 ? m.ctxMax : 1_000_000;
    const pctText = m.ctxPct !== null ? \`\${m.ctxPct}%\` : '--';
    const sysPct = Math.max(0, (m.sysTokens / maxCap) * 100);
    const toolPct = Math.max(0, (m.toolsTokens / maxCap) * 100);
    const chatPct = Math.max(0, (m.chatTokens / maxCap) * 100);
    const capText = m.ctxMax > 0 ? \`~\${fmtCompactTokens(m.ctxUsed)} / \${fmtCapacityTokens(m.ctxMax)}\` : '--';

    return \`
      <div class="agy-pop-head">
        <span class="agy-pop-title"><span class="agy-pop-title-muted">上下文已用</span> <span>\${pctText}</span></span>
        <span class="agy-pop-head-val agy-pop-head-val-muted">\${capText}</span>
      </div>
      <div class="agy-ctx-bar">
        \${m.sysTokens > 0 ? \`<div class="agy-ctx-seg" style="width:\${sysPct.toFixed(2)}%;background:#94a3b8;"></div>\` : ''}
        \${m.toolsTokens > 0 ? \`<div class="agy-ctx-seg" style="width:\${toolPct.toFixed(2)}%;background:#a78bfa;"></div>\` : ''}
        \${m.chatTokens > 0 ? \`<div class="agy-ctx-seg" style="width:\${chatPct.toFixed(2)}%;background:#3b82f6;"></div>\` : ''}
      </div>
      <div class="agy-pop-rows">
        <div class="agy-pop-row">
          <span class="agy-pop-label"><span class="agy-dot" style="background:#94a3b8;"></span><span>系统提示词</span></span>
          <span class="agy-pop-val">~\${fmtCompactTokens(m.sysTokens)}</span>
        </div>
        <div class="agy-pop-row">
          <span class="agy-pop-label"><span class="agy-dot" style="background:#a78bfa;"></span><span>工具定义</span></span>
          <span class="agy-pop-val">~\${fmtCompactTokens(m.toolsTokens)}</span>
        </div>
        <div class="agy-pop-row">
          <span class="agy-pop-label"><span class="agy-dot" style="background:#3b82f6;"></span><span>对话消息</span></span>
          <span class="agy-pop-val">~\${fmtCompactTokens(m.chatTokens)}</span>
        </div>
      </div>
      \${m.modelName ? \`
        <div class="agy-pop-divider"></div>
        <div class="agy-pop-row agy-pop-row-sub">
          <span class="agy-pop-label">响应模型</span>
          <span class="agy-pop-model" title="\${escapeHtml(m.modelName)}">\${escapeHtml(m.modelName)}</span>
        </div>
      \` : ''}
    \`;
  }

  function getOrCreatePopover() {
    let pop = document.getElementById(POPOVER_ID);
    if (pop) return pop;
    pop = document.createElement('div');
    pop.id = POPOVER_ID;
    pop.style.display = 'none';
    pop.addEventListener('mouseenter', () => {
      if (closeTimer) { clearTimeout(closeTimer); closeTimer = null; }
    });
    pop.addEventListener('mouseleave', () => {
      if (activeState && !activeState.pinned) scheduleClose();
    });
    document.body.appendChild(pop);
    return pop;
  }

  function positionPopover(pop, anchorEl) {
    const rect = anchorEl.getBoundingClientRect();
    const popRect = pop.getBoundingClientRect();
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    let left = rect.right - popRect.width;
    if (left < 8) left = 8;
    if (left + popRect.width > vw - 8) left = Math.max(8, vw - popRect.width - 8);
    let top = rect.bottom + 6;
    if (top + popRect.height > vh - 8) {
      top = Math.max(8, rect.top - popRect.height - 6);
    }
    pop.style.left = \`\${Math.round(left)}px\`;
    pop.style.top = \`\${Math.round(top)}px\`;
  }

  function clearActiveMarkers() {
    document.querySelectorAll('.agy-tel-pill[data-active="true"]').forEach((p) => {
      p.removeAttribute('data-active');
    });
  }

  function hidePopover() {
    if (closeTimer) { clearTimeout(closeTimer); closeTimer = null; }
    activeState = null;
    clearActiveMarkers();
    const pop = document.getElementById(POPOVER_ID);
    if (pop) {
      pop.removeAttribute('data-open');
      pop.style.display = 'none';
    }
  }

  function scheduleClose() {
    if (closeTimer) clearTimeout(closeTimer);
    closeTimer = later(() => {
      if (activeState && !activeState.pinned) {
        hidePopover();
      }
    }, 150);
  }

  function showPopover(kind, anchorEl, cascadeId, metrics, pinned = false) {
    if (closeTimer) { clearTimeout(closeTimer); closeTimer = null; }
    clearActiveMarkers();
    anchorEl.setAttribute('data-active', 'true');
    activeState = { kind, anchorEl, cascadeId, pinned };

    const pop = getOrCreatePopover();
    pop.innerHTML = renderPopoverHtml(kind, metrics);
    pop.style.display = 'block';
    positionPopover(pop, anchorEl);
    requestAnimationFrame(() => {
      if (activeState && activeState.anchorEl === anchorEl) {
        pop.setAttribute('data-open', 'true');
      }
    });
  }

  function ensureBarForToolbar(toolbar, actionGroup, cascadeId) {
    let bar = toolbar.querySelector(\`[\${BAR_ATTR}]\`);
    if (!bar) {
      bar = document.createElement('div');
      bar.className = 'agy-telemetry-bar';
      bar.setAttribute(BAR_ATTR, '1');

      const makePill = (kind, initialIcon, initialText) => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'agy-tel-pill';
        btn.setAttribute('data-kind', kind);
        btn.innerHTML = \`<span class="agy-tel-icon">\${initialIcon}</span><span class="agy-tel-val">\${initialText}</span>\`;

        btn.addEventListener('mouseenter', () => {
          if (activeState?.pinned) return;
          const m = btn.__agyMetrics;
          if (m) showPopover(kind, btn, btn.__agyCascadeId, m, false);
        });
        btn.addEventListener('mouseleave', () => {
          if (!activeState?.pinned) scheduleClose();
        });
        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          const m = btn.__agyMetrics;
          if (!m) return;
          if (activeState && activeState.anchorEl === btn && activeState.pinned) {
            hidePopover();
          } else {
            showPopover(kind, btn, btn.__agyCascadeId, m, true);
          }
        });
        return btn;
      };

      bar.appendChild(makePill('speed', ICONS.speed, '-- tok/s'));
      bar.appendChild(makePill('cache', ICONS.cache, '--%'));
      bar.appendChild(makePill('context', makeRingSvg(null), '--%'));
    }

    if (bar.parentElement !== toolbar || bar.nextElementSibling !== actionGroup) {
      toolbar.insertBefore(bar, actionGroup);
    }
    bar.setAttribute('data-cascade-id', cascadeId);
    return bar;
  }

  function updateBar(bar, cascadeId, m) {
    const speedBtn = bar.querySelector('[data-kind="speed"]');
    const cacheBtn = bar.querySelector('[data-kind="cache"]');
    const ctxBtn = bar.querySelector('[data-kind="context"]');

    if (speedBtn) {
      speedBtn.__agyMetrics = m;
      speedBtn.__agyCascadeId = cascadeId;
      const valEl = speedBtn.querySelector('.agy-tel-val');
      const nextText = m.latestTps !== null ? \`\${m.latestTps} tok/s\` : '-- tok/s';
      if (valEl && valEl.textContent !== nextText) valEl.textContent = nextText;
    }

    if (cacheBtn) {
      cacheBtn.__agyMetrics = m;
      cacheBtn.__agyCascadeId = cascadeId;
      const valEl = cacheBtn.querySelector('.agy-tel-val');
      const nextText = m.cacheHitPct !== null ? \`\${m.cacheHitPct}%\` : '--%';
      if (valEl && valEl.textContent !== nextText) valEl.textContent = nextText;
    }

    if (ctxBtn) {
      ctxBtn.__agyMetrics = m;
      ctxBtn.__agyCascadeId = cascadeId;
      const iconEl = ctxBtn.querySelector('.agy-tel-icon');
      const valEl = ctxBtn.querySelector('.agy-tel-val');
      const nextText = m.ctxPct !== null ? \`\${m.ctxPct}%\` : '--%';
      if (valEl && valEl.textContent !== nextText) valEl.textContent = nextText;
      const pctKey = String(m.ctxPct);
      if (iconEl && ctxBtn.getAttribute('data-ring-pct') !== pctKey) {
        ctxBtn.setAttribute('data-ring-pct', pctKey);
        iconEl.innerHTML = makeRingSvg(m.ctxPct);
      }
    }

    if (activeState && activeState.cascadeId === cascadeId && activeState.anchorEl?.isConnected) {
      const pop = document.getElementById(POPOVER_ID);
      if (pop && pop.style.display === 'block') {
        pop.innerHTML = renderPopoverHtml(activeState.kind, m);
        positionPopover(pop, activeState.anchorEl);
      }
    }
  }

  function sync() {
    syncQueued = false;
    ensureStyle();

    const moreBtns = Array.from(document.querySelectorAll('button[data-testid="titlebar-more-actions"]'));
    const activeToolbars = new Set();

    for (const moreBtn of moreBtns) {
      const actionGroup = moreBtn.parentElement;
      const toolbar = moreBtn.closest('[data-testid="pane-titlebar-toolbar"]') || actionGroup?.parentElement;
      if (!toolbar || !actionGroup) continue;

      const cascadeId = extractCascadeIdFromBtn(moreBtn);
      if (!cascadeId) continue;

      activeToolbars.add(toolbar);
      const bar = ensureBarForToolbar(toolbar, actionGroup, cascadeId);
      const provider = getAgentStateProvider(toolbar, cascadeId);
      if (!provider) continue;

      const state = provider.getState();
      const metrics = computeMetrics(state, cascadeId);
      updateBar(bar, cascadeId, metrics);
    }

    // Remove stale bars whose toolbar disappeared or lost conversation button
    document.querySelectorAll(\`[\${BAR_ATTR}]\`).forEach((bar) => {
      if (!activeToolbars.has(bar.parentElement)) {
        bar.remove();
      }
    });

    if (activeState && (!activeState.anchorEl || !activeState.anchorEl.isConnected)) {
      hidePopover();
    }
  }

  function scheduleSync() {
    if (syncQueued) return;
    syncQueued = true;
    requestAnimationFrame(sync);
  }

  document.addEventListener('click', (e) => {
    if (!activeState) return;
    const pop = document.getElementById(POPOVER_ID);
    const inBar = e.target?.closest && e.target.closest(\`[\${BAR_ATTR}]\`);
    const inPop = pop && e.target && pop.contains(e.target);
    if (!inBar && !inPop) {
      hidePopover();
    }
  }, { capture: true, signal: abort.signal });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && activeState) {
      hidePopover();
    }
  }, { signal: abort.signal });

  window.addEventListener('resize', () => {
    if (activeState?.anchorEl?.isConnected) {
      const pop = document.getElementById(POPOVER_ID);
      if (pop && pop.style.display === 'block') positionPopover(pop, activeState.anchorEl);
    }
  }, { signal: abort.signal });

  domObserver = new MutationObserver(() => {
    scheduleSync();
  });
  if (document.body) {
    domObserver.observe(document.body, { childList: true, subtree: true });
  }

  pollTimer = setInterval(sync, 1000);

  window.__agy_telemetry_dispose = () => {
    abort.abort();
    if (domObserver) domObserver.disconnect();
    if (pollTimer) clearInterval(pollTimer);
    for (const tid of pendingTimers) clearTimeout(tid);
    pendingTimers.clear();
    for (const sub of subscriptions.values()) {
      try { disposeSub(sub.unsub); } catch {}
    }
    subscriptions.clear();
    liveStepTtft.clear();
    liveStepTrack.clear();
    seenWaitingSteps.clear();
    activeState = null;
    document.querySelectorAll(\`[\${BAR_ATTR}]\`).forEach((el) => el.remove());
    const pop = document.getElementById(POPOVER_ID);
    if (pop) pop.remove();
    const st = document.getElementById(STYLE_ID);
    if (st) st.remove();
  };

  sync();
})();
`;
}

async function main() {
  if (!Number.isInteger(serverPort) || serverPort < 1 || serverPort > 65535) {
    throw new Error('AGY_TELEMETRY_PORT must be an integer between 1 and 65535');
  }
  if (process.argv.includes('--stop')) {
    await stopService(serverPort);
    return;
  }
  if (process.argv.includes('--status')) {
    const status = await getJson(serverPort, '/health');
    if (status?.service !== 'agy-telemetry') throw new Error('Telemetry service is not running');
    console.log(JSON.stringify(status, null, 2));
    return;
  }
  if (typeof WebSocket !== 'function') {
    throw new Error('Node.js 22 or later with built-in WebSocket support is required');
  }

  const requestedPort = process.env.AGY_TELEMETRY_CDP_PORT ? Number(process.env.AGY_TELEMETRY_CDP_PORT) : null;
  if (requestedPort !== null && (!Number.isInteger(requestedPort) || requestedPort < 1 || requestedPort > 65535)) {
    throw new Error('Invalid AGY_TELEMETRY_CDP_PORT');
  }

  if (process.argv.includes('--once')) {
    const onceToken = crypto.randomBytes(16).toString('hex');
    const onceController = new CdpController({
      script: buildInjectionScript(onceToken),
      requestedPort,
    });
    const result = await onceController.injectOnce();
    if (!result.port) {
      console.log('[agy-telemetry] No active Antigravity CDP port found; nothing injected.');
    } else {
      console.log(`[agy-telemetry] Once mode attached ${result.attachedPages} page(s) on CDP port ${result.port}.`);
    }
    return;
  }

  let controller;
  let pollTimer;
  let stopping = false;
  const close = () => {
    if (stopping) return;
    stopping = true;
    clearInterval(pollTimer);
    controller?.stop();
    removeState(serverPort, token);
    server.close();
    server.closeAllConnections();
    const forceExit = setTimeout(() => process.exit(0), 150);
    forceExit.unref();
  };

  const { server, token } = createControlServer({
    port: serverPort,
    shutdown: close,
    status: () => ({
      cdpPort: controller?.port || null,
      attachedPages: controller?.attachedPages || 0,
    }),
  });

  try {
    await new Promise((resolve, reject) => {
      server.once('error', reject);
      server.listen(serverPort, '127.0.0.1', resolve);
    });
  } catch (error) {
    if (error.code === 'EADDRINUSE') {
      const existing = await getJson(serverPort, '/health');
      if (existing?.service === 'agy-telemetry') {
        console.log('[agy-telemetry] Service already running.');
        return;
      }
    }
    throw error;
  }

  try {
    writeState(serverPort, token);

    controller = new CdpController({
      script: buildInjectionScript(token),
      requestedPort,
      onHostGone: process.argv.includes('--daemon') ? close : () => {},
    });
    pollTimer = setInterval(() => controller.poll(), 5000);
    controller.poll();
    process.once('SIGINT', close);
    process.once('SIGTERM', close);
    server.on('error', (error) => {
      console.error(error.message);
      close();
    });
    console.log(`[agy-telemetry] HTTP health server listening on http://127.0.0.1:${serverPort}`);
    console.log('[agy-telemetry] Waiting for Antigravity CDP. Use --status or --stop to manage.');
  } catch (error) {
    close();
    throw error;
  }
}

if (require.main === module) {
  main().catch((error) => {
    console.error('[agy-telemetry]', error.message);
    process.exitCode = 1;
  });
}

module.exports = { createControlServer, buildInjectionScript };
