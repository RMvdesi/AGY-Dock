const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');

const {
  MIN_ZOOM,
  MAX_ZOOM,
  clampZoom,
  computeWordFitScale,
  computeExcelFitScale,
  computePptFitScale,
  computeWheelZoom,
  stepZoom,
  buildZoomStyles,
  buildZoomClientScript,
  patchExcelBundle,
} = require('../lib/preview-zoom');
const { createPreviewServer } = require('../index');

test('clampZoom bounds and sanitizes scales', () => {
  assert.equal(clampZoom(0.1), MIN_ZOOM);
  assert.equal(clampZoom(5), MAX_ZOOM);
  assert.equal(clampZoom(1.2345), 1.235);
  assert.equal(clampZoom(NaN), 1);
  assert.equal(clampZoom(-2), 1);
});

test('computeWordFitScale shrinks wide pages for narrow panes and caps at 100%', () => {
  const narrow = computeWordFitScale({ viewportWidth: 480, pageWidth: 816 });
  assert.ok(narrow > 0.5 && narrow < 0.65, `expected ~0.55, got ${narrow}`);

  const wide = computeWordFitScale({ viewportWidth: 1200, pageWidth: 816 });
  assert.equal(wide, 1);
});

test('computeExcelFitScale adapts wide sheets without upscaling narrow sheets', () => {
  assert.equal(computeExcelFitScale({ viewportWidth: 600, contentWidth: 420 }), 1);

  const fit = computeExcelFitScale({ viewportWidth: 600, contentWidth: 1164 });
  assert.ok(fit >= 0.45 && fit <= 0.55, `expected ~0.5, got ${fit}`);

  const superWide = computeExcelFitScale({ viewportWidth: 500, contentWidth: 5000 });
  assert.equal(superWide, 0.3);
});

test('computePptFitScale fits both narrow and short panes without clipping', () => {
  const narrow = computePptFitScale({ viewportWidth: 520, viewportHeight: 800 });
  assert.ok(narrow > 0.4 && narrow < 0.55, `expected ~0.465, got ${narrow}`);

  const shortWide = computePptFitScale({ viewportWidth: 1200, viewportHeight: 400 });
  assert.ok(shortWide > 0.5 && shortWide < 0.7, `expected height-constrained ~0.61, got ${shortWide}`);

  const large = computePptFitScale({ viewportWidth: 1400, viewportHeight: 900 });
  assert.equal(large, 1);
});

test('computeWheelZoom and stepZoom zoom in/out monotonically within limits', () => {
  const zoomedIn = computeWheelZoom(1, -100);
  const zoomedOut = computeWheelZoom(1, 100);
  assert.ok(zoomedIn > 1.05 && zoomedIn < 1.25);
  assert.ok(zoomedOut < 0.95 && zoomedOut > 0.8);
  assert.equal(computeWheelZoom(MAX_ZOOM, -120), MAX_ZOOM);
  assert.equal(computeWheelZoom(MIN_ZOOM, 120), MIN_ZOOM);
  assert.equal(stepZoom(1, 1), 1.1);
  assert.equal(stepZoom(1, -1), 0.9);
});

test('patchExcelBundle patches zoom bounds, wheel throttle, and load hook', () => {
  const excelAsset = fs
    .readdirSync(path.join(__dirname, '..', 'webview', 'assets'))
    .find((name) => /^Excel-.*\.js$/i.test(name));
  assert.ok(excelAsset, 'Expected bundled Excel JS asset');
  const raw = fs.readFileSync(path.join(__dirname, '..', 'webview', 'assets', excelAsset), 'utf8');
  const patched = patchExcelBundle(raw);
  assert.match(patched, /qR=\.25,JR=3/);
  assert.match(patched, /oU=\.08,sU=16/);
  assert.match(patched, /window\.__ag_excel_onLoad&&window\.__ag_excel_onLoad\(p\)/);
});

test('buildZoomStyles and buildZoomClientScript render valid syntax for all routes', () => {
  for (const route of ['word', 'excel', 'ppt']) {
    const css = buildZoomStyles(route);
    const js = buildZoomClientScript(route);
    assert.match(css, /#ag-zoom-hud/);
    assert.match(js, /window\.addEventListener\('wheel'/);
    assert.match(js, /e\.ctrlKey \|\| e\.metaKey/);
    // Ensure generated client script parses cleanly
    new Function(js);
  }
});

test('preview server injects zoom HUD and patched Excel bundle over HTTP', async () => {
  const fixturePath = path.join(__dirname, '..', 'package.json');
  const { server, token } = createPreviewServer({ port: 0 });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address();
  try {
    // Reject non-office extension with 415
    const badRes = await fetch(`http://127.0.0.1:${port}/?token=${token}&file=${encodeURIComponent(fixturePath)}`);
    assert.equal(badRes.status, 415);

    const healthRes = await fetch(`http://127.0.0.1:${port}/health`);
    assert.equal(healthRes.status, 200);
    const health = await healthRes.json();
    assert.equal(health.service, 'antigravity-office-viewer');
    assert.equal(health.version, require('../package.json').version);

    const excelAsset = fs
      .readdirSync(path.join(__dirname, '..', 'webview', 'assets'))
      .find((name) => /^Excel-.*\.js$/i.test(name));
    const jsRes = await fetch(`http://127.0.0.1:${port}/assets/${excelAsset}`);
    assert.equal(jsRes.status, 200);
    const jsBody = await jsRes.text();
    assert.match(jsBody, /qR=\.25,JR=3/);
    assert.match(jsBody, /__ag_excel_onLoad/);

    const os = require('node:os');
    const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'ag-ov-'));
    try {
      for (const [ext, expectedRoute] of [['.docx', 'word'], ['.xlsx', 'excel'], ['.pptx', 'ppt']]) {
        const docPath = path.join(tmpDir, 'sample' + ext);
        fs.writeFileSync(docPath, 'stub');
        const pageRes = await fetch(`http://127.0.0.1:${port}/?token=${token}&file=${encodeURIComponent(docPath)}`);
        assert.equal(pageRes.status, 200);
        const html = await pageRes.text();
        assert.match(html, new RegExp(`const ROUTE = "${expectedRoute}"`));
        assert.match(html, /#ag-zoom-hud/);
        assert.match(html, /__ag_office_zoom/);
      }
    } finally {
      fs.rmSync(tmpDir, { recursive: true, force: true });
    }
  } finally {
    await new Promise((resolve) => server.close(resolve));
  }
});
