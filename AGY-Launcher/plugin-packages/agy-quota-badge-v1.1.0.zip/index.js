const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const crypto = require('node:crypto');
const { CdpController, getJson } = require('./lib/cdp');
const { writeState, removeState, stopService } = require('./lib/service');
const { DEFAULT_PALETTE_KEY, resolvePalette } = require('./lib/palettes');
const { name, version } = require('./package.json');
const port = Number(process.env.AGY_QUOTA_BADGE_PORT || 12409);

function loadSettings(settingsPath = path.join(__dirname, 'settings.json')) {
  const defaults = { palette: DEFAULT_PALETTE_KEY };
  try {
    if (!fs.existsSync(settingsPath)) return defaults;
    const content = fs.readFileSync(settingsPath, 'utf8').replace(/^\uFEFF/, '');
    const raw = JSON.parse(content);
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return defaults;
    const resolved = resolvePalette(raw);
    return {
      ...raw,
      palette: resolved.id,
    };
  } catch {
    return defaults;
  }
}

function injectionScript(overrideSettings = null) {
  const settings = overrideSettings && typeof overrideSettings === 'object'
    ? { ...overrideSettings, palette: resolvePalette(overrideSettings).id }
    : loadSettings();
  const read = file => fs.readFileSync(path.join(__dirname, 'lib', file), 'utf8');
  return '(() => {\n"use strict";\n'
    + read('palettes.js') + '\n'
    + read('badge.js') + '\n'
    + read('quota.js') + '\n'
    + read('renderer.js')
    + '\nmountQuotaBadge(' + JSON.stringify(read('badge.css')) + ', ' + JSON.stringify(settings) + ');\n})()';
}

function cdpPort() {
  const idx = process.argv.indexOf('--cdp-port');
  const value = process.env.AGY_QUOTA_BADGE_CDP_PORT || (idx < 0 ? '' : process.argv[idx + 1]);
  if (!value || value === '{CDP_PORT}') return null;
  const n = Number(value);
  if (!Number.isInteger(n) || n < 1 || n > 65535) throw new Error('Invalid CDP port');
  return n;
}

const log = message => console.log(new Date().toISOString(), '[' + name + ']', message);

async function main() {
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('Invalid health port');
  if (process.argv.includes('--stop')) {
    if ((await getJson(port, '/health'))?.service === name) await stopService(port);
    return;
  }
  if (process.argv.includes('--status')) {
    const status = await getJson(port, '/health');
    if (status?.service !== name) throw new Error('Service is not running');
    console.log(JSON.stringify(status));
    return;
  }
  if (typeof WebSocket !== 'function') throw new Error('Node.js 22 or later is required');

  const token = crypto.randomBytes(24).toString('hex');
  let pollTimer;
  let stopping = false;
  const activeSettings = loadSettings();
  const controller = new CdpController({
    script: injectionScript(activeSettings), requestedPort: cdpPort(), onHostGone: close,
  });
  const server = http.createServer((req, res) => {
    if (req.method === 'GET' && req.url === '/health') {
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify({
        service: name,
        version,
        cdpPort: controller.port,
        attachedPages: controller.attachedPages,
        palette: activeSettings.palette,
      }));
      return;
    }
    if (req.method === 'POST' && req.url === '/api/shutdown') {
      if (req.headers.authorization !== 'Bearer ' + token) {
        res.writeHead(403).end();
        return;
      }
      res.writeHead(200, { Connection: 'close' });
      res.end(() => void close());
      return;
    }
    res.writeHead(404).end();
  });
  async function close() {
    if (stopping) return;
    stopping = true;
    clearInterval(pollTimer);
    await controller.shutdown();
    removeState(port, token);
    server.close();
    server.closeAllConnections();
    log('Stopped');
  }
  try {
    await new Promise((resolve, reject) => {
      server.once('error', reject);
      server.listen(port, '127.0.0.1', resolve);
    });
  } catch (error) {
    if (error.code === 'EADDRINUSE' && (await getJson(port, '/health'))?.service === name) {
      log('Service already running');
      return;
    }
    throw error;
  }
  try {
    writeState(port, token);
    process.once('SIGINT', close);
    process.once('SIGTERM', close);
    pollTimer = setInterval(() => void controller.poll(), 5000);
    void controller.poll();
    log('Listening on 127.0.0.1:' + port + ' (palette=' + activeSettings.palette + ')');
  } catch (error) {
    await close();
    throw error;
  }
}

if (require.main === module) {
  main().catch(error => {
    console.error('[' + name + ']', error.message);
    process.exitCode = 1;
  });
}
module.exports = { injectionScript, loadSettings };
